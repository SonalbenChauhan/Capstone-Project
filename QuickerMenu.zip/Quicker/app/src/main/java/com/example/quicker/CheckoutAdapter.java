package com.example.quicker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CheckoutAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<Order> orderList;

    public CheckoutAdapter(Context context, List<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
    }



    public  class ViewHolder extends RecyclerView.ViewHolder {
        public TextView ordername;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ordername = (TextView)itemView.findViewById(R.id.txtTitle);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_menu_record,parent,false);
        return  new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Order current = orderList.get(position);
        ((ViewHolder)holder).ordername.setText(current.getNames().get(position));

    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }
}
