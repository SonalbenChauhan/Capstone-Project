package com.example.quicker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MenuItemDetails extends AppCompatActivity {
    TextView title, menuPrice,menuCategory, menuDescription;
    ImageView imageView;
    Button order, backToList,checkout;
    int price;
    String name;
    String url;
    String category;
    String description;
    ArrayList<String> orderNames = new ArrayList<String>();
    ArrayList<String> orderPrice = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_item_details);
        title=findViewById(R.id.txtTitle);
        menuPrice=findViewById(R.id.txtPrice);
        menuCategory=findViewById(R.id.txtCategory);
        menuDescription=findViewById(R.id.txtDescription);
        imageView=findViewById(R.id.imgView);
        order=findViewById(R.id.btnOrder);
        backToList=findViewById(R.id.btnBack);
        checkout = findViewById(R.id.checkout);
        Intent i = getIntent();
        name = i.getStringExtra("itemName");
        category = i.getStringExtra("itemCategory");
        url = i.getStringExtra("itemUrl");
        description = i.getStringExtra("description");
        price = i.getIntExtra("itemPrice",0);

        title.setText(name);
        menuPrice.setText("$"+String.valueOf(price));
        menuCategory.setText(category);
        menuDescription.setText(description);
        Picasso.get().load(url).into(imageView);

        backToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(),MenuItemsActivity.class);
                startActivity(intent);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("OrdersToBePlaced");
//                DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference().child("pricesoforders");
                String itemname = title.getText().toString() + ":" +" $"+ String.valueOf(price);
//                String itemPrice = String.valueOf(price);
                orderNames.add(itemname);
//                orderPrice.add(itemPrice);
                databaseReference.push().setValue(orderNames);
//                databaseReference1.push().setValue(orderPrice);
                Toast toast = Toast.makeText(MenuItemDetails.this,itemname+" is added",Toast.LENGTH_LONG);
                View view = toast.getView();
                toast.show();
            }
        });

        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuItemDetails.this,Checkout.class);
                startActivity(intent);
            }
        });
    }
}
