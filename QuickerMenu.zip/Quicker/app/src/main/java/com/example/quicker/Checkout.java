package com.example.quicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Checkout extends AppCompatActivity {
    String content;
    TextView order;
    Button btnOrder;
    private RecyclerView recyclerView;
    private List<Order> items;
    private CheckoutAdapter checkoutAdapter;
    private DatabaseReference databaseReference123;
    ArrayList<String> ordernames = new ArrayList<>();
    ArrayList<String> ordernamesadjusted = new ArrayList<>();
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        btnOrder = findViewById(R.id.btnOrder);

        items = new ArrayList<>();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("OrdersToBePlaced");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();
                Log.d("map",String.valueOf(map));
                final String[] names = String.valueOf(map).split(",");
//                orderprice = new Integer[100];
                for (int i=0;i<=names.length-1;i++){
                    Log.d("names",names[i]);
                            if (String.valueOf(map).contains("null")){
                                break;
                            }
                            String trimmed = names[i].substring(1,names[i].length()-1).trim();
                            Log.d("trimmed",trimmed);
                            if (trimmed.contains("[")){
                                String sub = trimmed.substring(0,trimmed.indexOf("["));
                                Log.d("sub",sub);
                                String rep = trimmed.replace(sub,"").trim();
                                Log.d("rep",rep);
                                if (rep.contains("]")){
                                    ordernames.add(rep.substring(1,rep.length()-1));
                                } else if (!rep.contains("]")){
                                    int l = rep.length();
                                    ordernames.add(rep.substring(1,l));
                        }

                    }
                }
                System.out.println(ordernames.size());
                StringBuilder stringBuilder = new StringBuilder();
                for (String s: ordernames){
                    stringBuilder.append(s + "\n");
                }
                order = findViewById(R.id.txtorder);
                order.setText(stringBuilder.toString());


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Checkout.this,databaseError.getMessage(),Toast.LENGTH_SHORT).show();

            }
        });

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0);
                String CustomerName = pref.getString("CustomerName",null);
                Order order = new Order();
                DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference().child("Orders");
                for (String s: ordernames){
                    Log.d("ordernames",s);
                    int i = s.indexOf(":");
                    String a = s.substring(0,i);
                    Log.d("ordernames1",a);
                    ordernamesadjusted.add(a);
                }
                order.setNames(ordernamesadjusted);
                order.setUserName(CustomerName);
                String tst = "";
                for (int i=0;i<=ordernames.size()-1;i++){
                    tst = tst +  ordernames.get(i);
                }
                Toast.makeText(getApplicationContext(),tst+"\n",Toast.LENGTH_LONG).show();
//                order.setPrices(orderPrices);
                databaseReference1.push().setValue(order);
                DatabaseReference databaseReference2 = FirebaseDatabase.getInstance().getReference().child("OrdersToBePlaced");
                databaseReference2.removeValue();
//                ordernames = new String[100];
            }
        });


    }
}
